import { useEffect, useMemo, useState } from 'react'
import { Activity, BarChart3, Check, ChevronRight, FlaskConical, Gauge, History, Info, LockKeyhole, Menu, Play, Shield, ShieldCheck, SlidersHorizontal, X } from 'lucide-react'
import Dashboard from './components/Dashboard'
import Monitor from './components/Monitor'
import Phone from './components/Phone'
import { makeEvent, scoreEvents } from './engine'
import { scenarios, type EventLog, type EventType, type Session } from './types'

type Tab = 'inicio' | 'laboratorio' | 'evidencias'
type AlertType = 'vishing' | 'critical' | 'smishing' | null

const STORAGE_KEY = 'escudo-contextual-sessions-v2'

export default function App() {
  const [tab, setTab] = useState<Tab>('inicio')
  const [mobileMenu, setMobileMenu] = useState(false)
  const [scenario, setScenario] = useState(1)
  const [participant, setParticipant] = useState('P-001')
  const [protection, setProtection] = useState(true)
  const [running, setRunning] = useState(false)
  const [step, setStep] = useState(0)
  const [events, setEvents] = useState<EventLog[]>([])
  const [alert, setAlert] = useState<AlertType>(null)
  const [alertCount, setAlertCount] = useState(0)
  const [startedAt, setStartedAt] = useState('')
  const [sessionDraft, setSessionDraft] = useState<Partial<Session>>({})
  const [rating, setRating] = useState(0)
  const [showFinish, setShowFinish] = useState(false)
  const [sessions, setSessions] = useState<Session[]>(() => {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]') } catch { return [] }
  })

  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions)) }, [sessions])

  const currentScenario = scenarios.find((item) => item.id === scenario)!
  const completed = sessions.filter((s) => s.endedAt)
  const totalAlerts = completed.filter((s) => s.protection && s.maxRisk >= 60).length
  const score = scoreEvents(events)

  const addEvent = (type: EventType) => {
    setEvents((previous) => {
      const activeCall = previous.some((event) => event.type === 'CALL_STARTED') && !previous.some((event) => event.type === 'CALL_ENDED')
      return [...previous, makeEvent(type, activeCall)]
    })
  }

  const logDecision = (label: string) => setEvents((previous) => [...previous, {
    id: crypto.randomUUID(), type: 'DECISION', label, timestamp: new Date().toISOString(), score: 0,
  }])

  const startScenario = () => {
    const now = new Date().toISOString()
    let initial: EventLog[] = []
    if (scenario === 2) {
      const call = makeEvent('CALL_STARTED')
      initial = [call, makeEvent('BANK_APP_OPENED', true)]
    }
    if (scenario === 3) initial = [makeEvent('SMS_RECEIVED')]
    setStartedAt(now)
    setEvents(initial)
    setStep(0)
    setAlert(null)
    setAlertCount(0)
    setRating(0)
    setSessionDraft({ outcome: '', safeDecision: false, consultedOtp: false, cancelled: false, ignoredWarning: false })
    setRunning(true)
    setShowFinish(false)
  }

  const finish = (patch: Partial<Session> = {}) => {
    setSessionDraft((old) => ({ ...old, ...patch }))
    setAlert(null)
    setShowFinish(true)
  }

  const saveSession = () => {
    const endedAt = new Date().toISOString()
    const endEvent: EventLog = { id: crypto.randomUUID(), type: 'SESSION_ENDED', label: 'Sesión finalizada', timestamp: endedAt, score: 0 }
    const finalEvents = [...events, endEvent]
    const duration = Math.max(1, Math.round((Date.now() - new Date(startedAt).getTime()) / 1000))
    const saved: Session = {
      id: `S-${String(sessions.length + 1).padStart(3, '0')}`,
      participant: participant.trim() || 'Anónimo',
      scenario,
      protection,
      startedAt,
      endedAt,
      duration,
      events: finalEvents,
      maxRisk: Math.max(scoreEvents(finalEvents), score),
      outcome: sessionDraft.outcome || 'Escenario completado',
      safeDecision: sessionDraft.safeDecision ?? false,
      consultedOtp: sessionDraft.consultedOtp ?? false,
      cancelled: sessionDraft.cancelled ?? false,
      ignoredWarning: sessionDraft.ignoredWarning ?? false,
      satisfaction: rating || undefined,
    }
    setSessions((old) => [...old, saved])
    setEvents(finalEvents)
    setRunning(false)
    setShowFinish(false)
    setParticipant((value) => value.replace(/\d+$/, (number) => String(Number(number) + 1).padStart(number.length, '0')))
  }

  const triggerAlert = (type: Exclude<AlertType, null>) => {
    if (protection) {
      setAlert(type)
      setAlertCount((value) => value + 1)
    }
  }

  const handleAction = (action: string) => {
    if (action === 'answer') { addEvent('CALL_STARTED'); setStep(1) }
    if (action === 'heard') setStep(2)
    if (action === 'open-bank') {
      addEvent('BANK_APP_OPENED')
      if (scenario === 4) setStep(1)
      else { setStep(3); setTimeout(() => triggerAlert('vishing'), 0) }
    }
    if (action === 'end-call') { addEvent('CALL_ENDED'); logDecision('Finalizó la llamada sospechosa'); finish({ outcome: 'Llamada sospechosa finalizada', safeDecision: true, cancelled: true }) }
    if (action === 'close-bank') { addEvent('BANK_APP_CLOSED'); logDecision('Cerró la aplicación financiera'); finish({ outcome: 'Aplicación financiera cerrada', safeDecision: true, cancelled: true }) }
    if (action === 'acknowledge') { logDecision('Reconoció la alerta'); setAlert(null); finish({ outcome: 'Alerta reconocida', safeDecision: true }) }
    if (action === 'otp') {
      addEvent('OTP_VIEW_REQUESTED')
      setSessionDraft((old) => ({ ...old, consultedOtp: true }))
      if (scenario === 1 && protection) triggerAlert('vishing')
      if (scenario === 1 && !protection) finish({ outcome: 'Clave ficticia consultada durante llamada', consultedOtp: true, safeDecision: false })
    }
    if (action === 'start-transfer') { addEvent('TRANSFER_STARTED'); setStep(scenario === 2 ? 1 : 2) }
    if (action === 'new-beneficiary') { addEvent('NEW_BENEFICIARY'); setStep(2) }
    if (action === 'enter-amount') {
      if (scenario === 2) { addEvent('UNUSUAL_AMOUNT'); setStep(3); setTimeout(() => triggerAlert('critical'), 0) }
      else setStep(3)
    }
    if (action === 'cancel-transfer' || action === 'verify') { logDecision(action === 'verify' ? 'Decidió verificar por un canal oficial' : 'Canceló la transferencia'); finish({ outcome: action === 'verify' ? 'Verificación solicitada' : 'Transferencia cancelada', safeDecision: true, cancelled: true }) }
    if (action === 'continue-anyway') { logDecision('Ignoró la alerta y continuó'); setAlert(null); setStep(4); setSessionDraft((old) => ({ ...old, outcome: 'Operación simulada continuada', ignoredWarning: true, safeDecision: false })) }
    if (action === 'view-balance') setStep(1)
    if (action === 'confirm-legit') { logDecision('Confirmó operación habitual'); setStep(4); setSessionDraft((old) => ({ ...old, outcome: 'Transferencia habitual exitosa', safeDecision: true })) }
    if (action === 'open-sms') setStep(1)
    if (action === 'open-link') { addEvent('SUSPICIOUS_LINK_OPENED'); setStep(2); setTimeout(() => triggerAlert('smishing'), 0) }
    if (action === 'close-link' || action === 'recommendations') { logDecision(action === 'close-link' ? 'Cerró el enlace sospechoso' : 'Consultó recomendaciones'); finish({ outcome: action === 'close-link' ? 'Enlace cerrado' : 'Recomendaciones consultadas', safeDecision: true, cancelled: true }) }
    if (action === 'ignore') { logDecision('Ignoró la advertencia'); setAlert(null); finish({ outcome: 'Advertencia ignorada', ignoredWarning: true, safeDecision: false }) }
    if (action === 'finish') {
      if (scenario === 1 && step === 0) finish({ outcome: 'Llamada rechazada', safeDecision: true, cancelled: true })
      else finish(sessionDraft)
    }
  }

  const openLab = (id?: number) => {
    if (id) setScenario(id)
    setTab('laboratorio')
    setMobileMenu(false)
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <button className="brand" onClick={() => setTab('inicio')}>
          <span className="brand-mark"><ShieldCheck size={23} /></span>
          <span><strong>Escudo Contextual</strong><small>Protección inteligente</small></span>
        </button>
        <nav className={mobileMenu ? 'open' : ''}>
          <button className={tab === 'inicio' ? 'active' : ''} onClick={() => { setTab('inicio'); setMobileMenu(false) }}><Gauge size={17} /> Centro de protección</button>
          <button className={tab === 'laboratorio' ? 'active' : ''} onClick={() => openLab()}><FlaskConical size={17} /> Laboratorio</button>
          <button className={tab === 'evidencias' ? 'active' : ''} onClick={() => { setTab('evidencias'); setMobileMenu(false) }}><BarChart3 size={17} /> Evidencias</button>
        </nav>
        <div className="header-status"><span /><div><strong>Motor activo</strong><small>Entorno simulado</small></div></div>
        <button className="menu-btn" onClick={() => setMobileMenu(!mobileMenu)}>{mobileMenu ? <X /> : <Menu />}</button>
      </header>

      <main>
        {tab === 'inicio' && <Home sessions={completed} totalAlerts={totalAlerts} onOpenLab={openLab} onEvidence={() => setTab('evidencias')} />}
        {tab === 'laboratorio' && <div className="lab-page">
          <div className="section-heading lab-heading"><div><span className="eyebrow">LABORATORIO DE ESCENARIOS</span><h1>Simulación contextual</h1><p>Reproduce eventos del dispositivo y observa cómo se correlacionan en tiempo real.</p></div>
            {running && <div className="live-badge"><span /> SESIÓN EN CURSO · {participant}</div>}
          </div>
          {!running && <Setup participant={participant} setParticipant={setParticipant} scenario={scenario} setScenario={setScenario} protection={protection} setProtection={setProtection} onStart={startScenario} />}
          <div className={`simulator-grid ${!running ? 'preview-disabled' : ''}`}>
            <Phone scenario={scenario} step={step} running={running} protection={protection} alert={alert} onAction={handleAction} />
            <Monitor events={events} protection={protection} alertCount={alertCount} />
          </div>
          <div className="demo-sequence"><span>Evento del dispositivo</span><ChevronRight /><span>Correlación de señales</span><ChevronRight /><span>Cálculo de riesgo</span><ChevronRight /><span>Alerta preventiva</span><ChevronRight /><span>Decisión</span><ChevronRight /><span>Evidencia</span></div>
        </div>}
        {tab === 'evidencias' && <Dashboard sessions={sessions} onReset={() => { if (confirm('¿Eliminar todas las sesiones de prueba guardadas en este navegador?')) setSessions([]) }} />}
      </main>

      <footer><Shield size={15} /><span><strong>Prototipo académico.</strong> Los eventos, llamadas y operaciones son simulados. La detección automática de aplicaciones y llamadas reales requiere una implementación móvil con permisos y capacidades compatibles.</span><LockKeyhole size={15} /><span>Sin datos financieros reales</span></footer>

      {showFinish && <div className="modal-backdrop"><div className="finish-modal">
        <div className="finish-icon"><Check /></div><span className="eyebrow">ESCENARIO COMPLETADO</span><h2>Registra la percepción del participante</h2><p>Resultado: <strong>{sessionDraft.outcome || 'Escenario completado'}</strong>. La calificación es opcional.</p>
        <label>Satisfacción con la experiencia</label><div className="rating">{[1, 2, 3, 4, 5].map((value) => <button className={rating >= value ? 'active' : ''} onClick={() => setRating(value)} key={value}>{value}</button>)}</div>
        <button className="primary-btn full" onClick={saveSession}>Guardar sesión y ver evidencia</button>
      </div></div>}
    </div>
  )
}

function Home({ sessions, totalAlerts, onOpenLab, onEvidence }: { sessions: Session[]; totalAlerts: number; onOpenLab: (id?: number) => void; onEvidence: () => void }) {
  const recent = sessions.slice(-3).reverse()
  return <div className="home-page">
    <section className="hero">
      <div className="hero-copy"><span className="active-chip"><Activity size={14} /> PROTECCIÓN CONTEXTUAL ACTIVA</span><h1>Tu seguridad, atenta<br />cuando más la necesitas.</h1><p>Escudo identifica situaciones potencialmente peligrosas en banca digital y te alerta antes de que una decisión se convierta en fraude.</p>
        <div className="hero-actions"><button className="primary-btn" onClick={() => onOpenLab(1)}><Play size={17} fill="currentColor" /> Iniciar demostración</button><button className="text-btn" onClick={onEvidence}>Ver evidencia <ChevronRight size={16} /></button></div>
      </div>
      <div className="protection-orbit"><div className="orbit orbit-1" /><div className="orbit orbit-2" /><div className="shield-center"><Shield size={52} /><span><i /> Motor evaluando</span></div><div className="signal-tag tag-1"><PhoneMini /> Llamada</div><div className="signal-tag tag-2"><LockKeyhole size={15} /> Privacidad</div><div className="signal-tag tag-3"><Activity size={15} /> Contexto</div></div>
    </section>

    <section className="overview">
      <div className="overview-title"><div><span className="eyebrow">CENTRO DE PROTECCIÓN PERSONAL</span><h2>Todo está bajo control</h2></div><span className="updated"><i /> Última evaluación: ahora</span></div>
      <div className="status-grid">
        <div className="main-status-card"><div className="status-icon"><ShieldCheck /></div><div><span>Estado de protección</span><h3>Protección contextual activa</h3><p>El motor está preparado para evaluar señales autorizadas.</p></div><span className="check-circle"><Check /></span></div>
        <SmallStatus icon={<Activity />} label="Motor de seguridad" value="Operativo" tone="green" />
        <SmallStatus icon={<History />} label="Sesiones realizadas" value={String(sessions.length)} tone="blue" />
        <SmallStatus icon={<Shield />} label="Alertas en pruebas" value={String(totalAlerts)} tone="orange" />
        <SmallStatus icon={<SlidersHorizontal />} label="Permisos" value="Simulados / No conectados" tone="gray" />
      </div>
    </section>

    <section className="scenario-section">
      <div className="section-mini-head"><div><span className="eyebrow">LABORATORIO DE VALIDACIÓN</span><h2>Explora situaciones de riesgo</h2><p>Escenarios reproducibles para demostrar cómo el Escudo actúa en el momento preciso.</p></div><button className="text-btn" onClick={() => onOpenLab()}>Ver laboratorio <ChevronRight /></button></div>
      <div className="scenario-grid">{scenarios.map((scenario) => <button className="scenario-card" key={scenario.id} onClick={() => onOpenLab(scenario.id)}><span className="scenario-number">0{scenario.id}</span><div className="scenario-icon" style={{ color: scenario.color, background: `${scenario.color}12` }}><Shield /></div><span>{scenario.short}</span><h3>{scenario.title}</h3><p>{scenario.description}</p><div>Ejecutar escenario <ChevronRight size={16} /></div></button>)}</div>
    </section>

    <section className="privacy-card"><div><LockKeyhole size={25} /></div><div><span className="eyebrow">PRIVACIDAD POR DISEÑO</span><h3>Tu información permanece bajo tu control</h3><p>Esta simulación no accede a llamadas, SMS, contactos, contraseñas ni aplicaciones reales. En una futura versión móvil, cada señal requerirá autorización explícita.</p></div><span className="local-pill">100% local</span></section>
    {recent.length > 0 && <section className="recent-section"><div className="section-mini-head"><h2>Actividad reciente</h2><button className="text-btn" onClick={onEvidence}>Ver todas</button></div>{recent.map((item) => <div className="recent-row" key={item.id}><div className="event-dot"><Check size={13} /></div><div><strong>{scenarios[item.scenario - 1].title}</strong><span>{item.participant} · {new Date(item.endedAt!).toLocaleString('es-CO')}</span></div><b>{item.outcome}</b></div>)}</section>}
  </div>
}

function Setup({ participant, setParticipant, scenario, setScenario, protection, setProtection, onStart }: { participant: string; setParticipant: (v: string) => void; scenario: number; setScenario: (v: number) => void; protection: boolean; setProtection: (v: boolean) => void; onStart: () => void }) {
  return <section className="setup-card"><div className="setup-head"><div><FlaskConical /><span><strong>Configurar sesión</strong><small>Datos anónimos, guardados localmente</small></span></div><span className="step-chip">PASO 1 DE 1</span></div>
    <div className="setup-form"><label>Identificador anónimo<input value={participant} onChange={(e) => setParticipant(e.target.value)} placeholder="Ej. P-001" /></label>
      <label>Escenario<select value={scenario} onChange={(e) => setScenario(Number(e.target.value))}>{scenarios.map((item) => <option key={item.id} value={item.id}>0{item.id} · {item.title}</option>)}</select></label>
      <div className="mode-field"><span>Modalidad</span><div className="segmented"><button className={protection ? 'active' : ''} onClick={() => setProtection(true)}><Shield size={16} /> Protección activada</button><button className={!protection ? 'active' : ''} onClick={() => setProtection(false)}>Modo control</button></div></div>
      <button className="primary-btn start-btn" onClick={onStart}><Play size={16} fill="currentColor" /> Iniciar escenario</button>
    </div>
    <div className="setup-note"><Info size={16} /><span>{protection ? 'Las alertas aparecerán únicamente cuando las reglas alcancen el umbral correspondiente.' : 'Modo control: se registrarán eventos y decisiones, pero no se mostrarán alertas preventivas.'}</span></div>
  </section>
}

function SmallStatus({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: string; tone: string }) {
  return <div className="small-status"><div className={`small-icon ${tone}`}>{icon}</div><span>{label}</span><strong>{value}</strong></div>
}

function PhoneMini() { return <Activity size={15} /> }
