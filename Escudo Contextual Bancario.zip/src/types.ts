export type EventType =
  | 'CALL_STARTED'
  | 'CALL_ENDED'
  | 'BANK_APP_OPENED'
  | 'OTP_VIEW_REQUESTED'
  | 'TRANSFER_STARTED'
  | 'NEW_BENEFICIARY'
  | 'UNUSUAL_AMOUNT'
  | 'SMS_RECEIVED'
  | 'SUSPICIOUS_LINK_OPENED'
  | 'BANK_APP_CLOSED'

export type RiskLevel = 'Bajo' | 'Medio' | 'Alto' | 'Crítico'

export interface EventLog {
  id: string
  type: EventType | 'DECISION' | 'SESSION_STARTED' | 'SESSION_ENDED'
  label: string
  timestamp: string
  score: number
}

export interface Session {
  id: string
  participant: string
  scenario: number
  protection: boolean
  startedAt: string
  endedAt?: string
  duration?: number
  events: EventLog[]
  maxRisk: number
  outcome: string
  safeDecision: boolean
  consultedOtp: boolean
  cancelled: boolean
  ignoredWarning: boolean
  satisfaction?: number
}

export interface Scenario {
  id: number
  short: string
  title: string
  description: string
  color: string
}

export const scenarios: Scenario[] = [
  { id: 1, short: 'Vishing', title: 'Falso asesor bancario', description: 'Llamada no verificada mientras se abre una app financiera.', color: '#B76534' },
  { id: 2, short: 'Presión', title: 'Transferencia bajo presión', description: 'Beneficiario nuevo y monto inusual durante una llamada.', color: '#B42318' },
  { id: 3, short: 'Smishing', title: 'Mensaje de texto fraudulento', description: 'Urgencia financiera y un dominio sospechoso.', color: '#7A5AF8' },
  { id: 4, short: 'Legítima', title: 'Operación bancaria habitual', description: 'Transferencia frecuente sin señales de riesgo.', color: '#168F8A' },
]
