import { Activity, CheckCircle2, Clock3, Radio, ShieldAlert } from 'lucide-react'
import { riskColor, riskLevel } from '../engine'
import type { EventLog } from '../types'

interface Props {
  events: EventLog[]
  protection: boolean
  alertCount: number
}

export default function Monitor({ events, protection, alertCount }: Props) {
  const score = Math.min(100, events.reduce((sum, event) => sum + event.score, 0))
  const active = events.filter((event) => event.score > 0)
  const last = events.at(-1)

  return (
    <section className="monitor-card">
      <div className="monitor-head">
        <div>
          <span className="eyebrow">MONITOR CONTEXTUAL</span>
          <h2>Motor de seguridad</h2>
        </div>
        <span className={`status-pill ${protection ? 'on' : 'off'}`}>
          <Radio size={13} /> {protection ? 'Protección activa' : 'Modo control'}
        </span>
      </div>

      <div className="risk-block">
        <div className="risk-ring" style={{ '--risk': `${score * 3.6}deg`, '--risk-color': riskColor(score) } as React.CSSProperties}>
          <div><strong>{score}</strong><small>/100</small></div>
        </div>
        <div>
          <span className="muted-label">Riesgo actual</span>
          <h3 style={{ color: riskColor(score) }}>{riskLevel(score)}</h3>
          <p>{score < 30 ? 'Contexto habitual, sin intervención.' : `${active.length} señales correlacionadas en esta sesión.`}</p>
        </div>
      </div>

      <div className="rule-card">
        <div className="rule-icon"><ShieldAlert size={18} /></div>
        <div>
          <span>Regla activada</span>
          <strong>{score >= 80 ? 'Contexto transaccional crítico' : score >= 60 ? 'Patrón de posible suplantación' : score >= 30 ? 'Contexto financiero sensible' : 'Ninguna regla preventiva'}</strong>
          <p>{score >= 30 ? 'Recomendación: detener y verificar por un canal oficial.' : 'El motor continúa evaluando señales simuladas.'}</p>
        </div>
      </div>

      <div className="signals-title">
        <span>Señales de la sesión</span>
        <span>{events.length} eventos</span>
      </div>
      <div className="event-feed">
        {events.length === 0 ? (
          <div className="empty-feed"><Activity size={20} /><p>Esperando el primer evento del dispositivo simulado.</p></div>
        ) : [...events].reverse().slice(0, 6).map((event, index) => (
          <div className="event-row" key={event.id}>
            <div className={`event-dot ${event.score ? 'risk' : ''}`}>{event.score ? <Activity size={13} /> : <CheckCircle2 size={13} />}</div>
            <div><strong>{event.label}</strong><span>{new Date(event.timestamp).toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span></div>
            {event.score > 0 && <b>+{event.score}</b>}
            {index === 0 && <em>Nuevo</em>}
          </div>
        ))}
      </div>

      <div className="monitor-foot">
        <span><Clock3 size={14} /> Última evaluación: {last ? 'ahora' : '—'}</span>
        <span>{alertCount} alertas</span>
      </div>
      <p className="parameter-note">Ponderaciones hipotéticas del prototipo. No son puntuaciones entrenadas ni validadas científicamente.</p>
    </section>
  )
}
