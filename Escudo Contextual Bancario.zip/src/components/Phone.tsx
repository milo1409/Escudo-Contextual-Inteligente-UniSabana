import { ArrowLeft, Banknote, Bell, Check, ChevronRight, CircleDollarSign, Clock3, KeyRound, LockKeyhole, MessageSquare, Phone as PhoneIcon, Shield, Smartphone, UserRound, Wifi, X } from 'lucide-react'

interface Props {
  scenario: number
  step: number
  running: boolean
  protection: boolean
  alert: 'vishing' | 'critical' | 'smishing' | null
  onAction: (action: string) => void
}

const Button = ({ children, onClick, secondary = false }: { children: React.ReactNode; onClick: () => void; secondary?: boolean }) => (
  <button className={secondary ? 'phone-btn secondary' : 'phone-btn'} onClick={onClick}>{children}</button>
)

export default function Phone({ scenario, step, running, protection, alert, onAction }: Props) {
  const home = !running || (step === 0 && scenario !== 2)
  const bankOpen = (scenario === 1 && step >= 3) || scenario === 2 || (scenario === 4 && step >= 1)

  return (
    <div className="phone-wrap">
      <div className="phone-label"><Smartphone size={16} /> TELÉFONO ANDROID SIMULADO</div>
      <div className="phone">
        <div className="phone-speaker" />
        <div className="phone-screen">
          <div className="phone-status"><span>9:41</span><span><Wifi size={13} /> 5G <strong>87%</strong></span></div>
          {!running && <IdleScreen onAction={onAction} />}
          {running && scenario === 1 && (
            <>
              {step === 0 && <IncomingCall onAction={onAction} />}
              {(step === 1 || step === 2) && <ActiveCall onAction={onAction} canOpen={step === 2} />}
              {bankOpen && <BankScreen scenario={scenario} step={step} protection={protection} onAction={onAction} />}
            </>
          )}
          {running && scenario === 2 && <BankScreen scenario={scenario} step={step} protection={protection} onAction={onAction} />}
          {running && scenario === 3 && (
            <>
              {step === 0 && <HomeScreen notification onAction={onAction} />}
              {step === 1 && <MessageScreen onAction={onAction} />}
              {step >= 2 && <FakeWeb protection={protection} onAction={onAction} />}
            </>
          )}
          {running && scenario === 4 && (
            <>
              {step === 0 && <HomeScreen onAction={onAction} />}
              {step >= 1 && <BankScreen scenario={scenario} step={step} protection={protection} onAction={onAction} />}
            </>
          )}
          {alert && protection && <SecurityAlert type={alert} onAction={onAction} />}
          {home && running && scenario !== 1 && scenario !== 3 && scenario !== 4 && <HomeScreen onAction={onAction} />}
          <div className="android-nav"><span /><span /><span /></div>
        </div>
      </div>
    </div>
  )
}

function IdleScreen({ onAction }: { onAction: (a: string) => void }) {
  return <div className="home-screen">
    <div className="home-time"><strong>9:41</strong><span>Martes, 18 de junio</span></div>
    <div className="empty-phone"><Shield size={40} /><strong>Simulador listo</strong><p>Inicia una sesión desde el laboratorio para reproducir señales.</p></div>
    <div className="dock"><button onClick={() => onAction('noop')}><PhoneIcon /></button><button><MessageSquare /></button><button><Banknote /></button></div>
  </div>
}

function HomeScreen({ notification = false, onAction }: { notification?: boolean; onAction: (a: string) => void }) {
  return <div className="home-screen">
    <div className="home-time"><strong>9:41</strong><span>Martes, 18 de junio</span></div>
    {notification && <button className="sms-notification" onClick={() => onAction('open-sms')}>
      <div className="app-icon messages"><MessageSquare size={19} /></div>
      <div><span>Mensajes · ahora</span><strong>Tu cuenta será bloqueada</strong><p>Verifica tus datos inmediatamente...</p></div>
    </button>}
    <div className="app-grid">
      <button onClick={() => onAction('open-bank')}><div className="app-icon bank"><Banknote /></div><span>Banco Demo</span></button>
      <button><div className="app-icon messages"><MessageSquare /></div><span>Mensajes</span></button>
      <button><div className="app-icon"><Clock3 /></div><span>Reloj</span></button>
      <button><div className="app-icon"><UserRound /></div><span>Contactos</span></button>
    </div>
    <div className="dock"><button><PhoneIcon /></button><button><MessageSquare /></button><button><Banknote /></button></div>
  </div>
}

function IncomingCall({ onAction }: { onAction: (a: string) => void }) {
  return <div className="call-screen">
    <span>Llamada entrante</span><div className="caller"><UserRound size={35} /></div>
    <h2>300 000 0000</h2><p>Número no verificado</p>
    <div className="call-actions"><button className="decline" onClick={() => onAction('finish')}><X /></button><button className="answer" onClick={() => onAction('answer')}><PhoneIcon /></button></div>
    <div className="call-labels"><span>Rechazar</span><span>Contestar</span></div>
  </div>
}

function ActiveCall({ onAction, canOpen }: { onAction: (a: string) => void; canOpen: boolean }) {
  return <div className="call-screen active-call">
    <span>Llamada en curso · 00:18</span><div className="caller"><UserRound size={35} /></div><h2>300 000 0000</h2>
    <div className="speech">“Somos del área de seguridad. Detectamos una compra sospechosa. Por favor, ingresa a tu aplicación bancaria”.</div>
    {!canOpen ? <Button onClick={() => onAction('heard')}>Continuar llamada</Button> : <Button onClick={() => onAction('open-bank')}><Banknote size={16} /> Abrir Banco Demo</Button>}
    <button className="end-call" onClick={() => onAction('end-call')}><PhoneIcon size={20} /></button>
  </div>
}

function BankScreen({ scenario, step, protection, onAction }: { scenario: number; step: number; protection: boolean; onAction: (a: string) => void }) {
  const transfer = (scenario === 2 && step >= 1) || (scenario === 4 && step >= 2)
  const result = (scenario === 2 && step >= 4) || (scenario === 4 && step >= 4)
  return <div className="bank-screen">
    <div className="bank-header"><div className="mini-logo"><Banknote size={17} /></div><strong>Banco Demo</strong><Bell size={17} /></div>
    {result ? <div className="success-state"><div><Check size={35} /></div><h2>Transferencia simulada</h2><p>La operación de demostración fue registrada. No se movió dinero real.</p><strong>{scenario === 2 ? '$850.000' : '$120.000'} COP</strong><Button onClick={() => onAction('finish')}>Finalizar escenario</Button></div>
    : transfer ? <div className="transfer-screen">
      <button className="back"><ArrowLeft size={17} /> Transferir</button>
      <label>Beneficiario</label><div className="field"><UserRound size={16} /> {scenario === 2 ? 'Nuevo beneficiario' : 'María G. · frecuente'}</div>
      <label>Monto</label><div className="amount-field"><span>$</span><strong>{scenario === 2 ? '850.000' : '120.000'}</strong><span>COP</span></div>
      <div className="safe-note"><LockKeyhole size={15} /> Operación ficticia para fines académicos</div>
      {scenario === 2 && step === 1 && <Button onClick={() => onAction('new-beneficiary')}>Seleccionar beneficiario nuevo</Button>}
      {((scenario === 2 && step === 2) || (scenario === 4 && step === 2)) && <Button onClick={() => onAction('enter-amount')}>Continuar con este monto</Button>}
      {scenario === 2 && step === 3 && !protection && <Button onClick={() => onAction('continue-anyway')}>Confirmar operación simulada</Button>}
      {scenario === 4 && step === 3 && <Button onClick={() => onAction('confirm-legit')}>Confirmar transferencia</Button>}
    </div>
    : <div className="bank-home">
      <span className="welcome">Hola, Andrea</span><div className="balance-card"><span>Saldo disponible</span><strong>$4.280.500</strong><small>Cuenta de ahorros · •• 4832</small></div>
      <div className="bank-actions"><button onClick={() => onAction(scenario === 4 ? 'view-balance' : 'start-transfer')}><CircleDollarSign /><span>{scenario === 4 ? 'Consultar saldo' : 'Transferir'}</span></button><button onClick={() => onAction('otp')}><KeyRound /><span>Clave dinámica</span></button></div>
      {scenario === 4 && step === 1 && <Button onClick={() => onAction('start-transfer')}>Transferir a contacto frecuente</Button>}
      {scenario === 1 && <div className="call-banner"><PhoneIcon size={13} /> Llamada activa · 300 000 0000</div>}
    </div>}
  </div>
}

function MessageScreen({ onAction }: { onAction: (a: string) => void }) {
  return <div className="message-screen"><div className="message-head"><ArrowLeft size={18} /><div>Sin identificar<span>SMS · ahora</span></div></div>
    <div className="message-bubble">Tu cuenta será bloqueada. Verifica tus datos inmediatamente en <button onClick={() => onAction('open-link')}>banc0-seguridad-ejemplo.test</button></div>
    <div className="sms-warning">Mensaje ficticio. No se abrirán sitios externos.</div>
  </div>
}

function FakeWeb({ protection, onAction }: { protection: boolean; onAction: (a: string) => void }) {
  return <div className="fake-web"><div className="browser-bar"><LockKeyhole size={13} /> banc0-seguridad-ejemplo.test</div><Shield size={40} /><h2>Página simulada</h2><p>Este sitio es una simulación. Nunca se solicitarán credenciales.</p>{!protection && <Button onClick={() => onAction('ignore')}>Continuar la prueba</Button>}</div>
}

function SecurityAlert({ type, onAction }: { type: 'vishing' | 'critical' | 'smishing'; onAction: (a: string) => void }) {
  const data = type === 'vishing'
    ? { title: '¡ATENCIÓN!', text: 'Estás utilizando una aplicación bancaria durante una llamada no verificada. Nunca compartas claves, códigos de seguridad o información financiera por teléfono.' }
    : type === 'critical'
      ? { title: 'RIESGO CRÍTICO', text: 'Esta operación reúne varias señales asociadas a posibles fraudes por ingeniería social. Te recomendamos detenerla y verificar directamente con tu banco.' }
      : { title: 'ENLACE SOSPECHOSO', text: 'Este mensaje utiliza señales frecuentes de suplantación bancaria. No ingreses contraseñas ni datos personales. Accede directamente a la aplicación oficial de tu banco.' }
  const actions = type === 'vishing'
    ? [['end-call', 'Finalizar llamada'], ['close-bank', 'Cerrar app bancaria'], ['acknowledge', 'Entendido']]
    : type === 'critical'
      ? [['cancel-transfer', 'Cancelar transferencia'], ['verify', 'Verificar seguridad'], ['continue-anyway', 'Continuar de todos modos']]
      : [['close-link', 'Cerrar enlace'], ['recommendations', 'Consultar recomendaciones'], ['ignore', 'Ignorar advertencia']]
  return <div className="alert-overlay"><div className={`security-alert ${type}`}>
    <div className="shield-alert"><Shield size={26} /></div><span>ESCUDO CONTEXTUAL</span><h2>{data.title}</h2><p>{data.text}</p>
    <div className="alert-actions">{actions.map(([key, label], i) => <button key={key} className={i === 2 ? 'tertiary' : ''} onClick={() => onAction(key)}>{label}{i < 2 && <ChevronRight size={15} />}</button>)}</div>
  </div></div>
}
