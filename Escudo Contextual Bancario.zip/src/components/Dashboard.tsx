import { BarChart3, Clock3, Download, FlaskConical, RotateCcw, ShieldCheck, Star, TriangleAlert } from 'lucide-react'
import { riskLevel } from '../engine'
import type { Session } from '../types'

export default function Dashboard({ sessions, onReset }: { sessions: Session[]; onReset: () => void }) {
  const done = sessions.filter((s) => s.endedAt)
  const alerts = done.filter((s) => s.protection && s.maxRisk >= 60).length
  const safe = done.filter((s) => s.safeDecision).length
  const avgTime = done.length ? Math.round(done.reduce((a, s) => a + (s.duration || 0), 0) / done.length) : 0
  const ratings = done.filter((s) => s.satisfaction)
  const avgRating = ratings.length ? ratings.reduce((a, s) => a + (s.satisfaction || 0), 0) / ratings.length : 0
  const protectedSessions = done.filter((s) => s.protection)
  const controlSessions = done.filter((s) => !s.protection)
  const safeRate = (items: Session[]) => items.length ? Math.round(items.filter((s) => s.safeDecision).length / items.length * 100) : 0
  const riskCounts = ['Bajo', 'Medio', 'Alto', 'Crítico'].map((level) => done.filter((s) => riskLevel(s.maxRisk) === level).length)

  const exportCsv = () => {
    const headers = ['sesion', 'participante', 'escenario', 'proteccion', 'inicio', 'duracion_seg', 'riesgo_max', 'resultado', 'decision_segura', 'cancelo', 'ignoro_alerta', 'satisfaccion']
    const rows = done.map((s) => [s.id, s.participant, s.scenario, s.protection ? 'activada' : 'desactivada', s.startedAt, s.duration, s.maxRisk, s.outcome, s.safeDecision, s.cancelled, s.ignoredWarning, s.satisfaction ?? ''])
    const csv = [headers, ...rows].map((row) => row.map((cell) => `"${String(cell ?? '').replaceAll('"', '""')}"`).join(',')).join('\n')
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }))
    const link = document.createElement('a'); link.href = url; link.download = `escudo-evidencias-${new Date().toISOString().slice(0, 10)}.csv`; link.click(); URL.revokeObjectURL(url)
  }

  return <div className="dashboard">
    <div className="section-heading"><div><span className="eyebrow">EVIDENCIA DEL PROTOTIPO</span><h1>Dashboard de validación</h1><p>Los indicadores se calculan exclusivamente con las sesiones ejecutadas en este navegador.</p></div>
      <div className="heading-actions"><button className="outline-btn" onClick={exportCsv} disabled={!done.length}><Download size={17} /> Exportar CSV</button><button className="danger-btn" onClick={onReset} disabled={!done.length}><RotateCcw size={16} /> Reiniciar</button></div>
    </div>

    {!done.length && <div className="no-data"><div><BarChart3 size={30} /></div><h2>Aún no hay evidencia recolectada</h2><p>Ejecuta un escenario desde el Laboratorio. Este panel no usa datos de demostración ni resultados precargados.</p></div>}

    <div className="metric-grid">
      <Metric icon={<FlaskConical />} label="Sesiones realizadas" value={done.length} />
      <Metric icon={<TriangleAlert />} label="Alertas generadas" value={alerts} />
      <Metric icon={<ShieldCheck />} label="Decisiones seguras" value={`${done.length ? Math.round(safe / done.length * 100) : 0}%`} />
      <Metric icon={<Clock3 />} label="Respuesta media" value={`${avgTime}s`} />
      <Metric icon={<Star />} label="Satisfacción" value={avgRating ? `${avgRating.toFixed(1)}/5` : '—'} />
    </div>

    <div className="charts-grid">
      <section className="chart-card">
        <div className="chart-title"><div><h3>Impacto de la protección</h3><p>Tasa de decisiones seguras por modalidad</p></div><span>{done.length} sesiones</span></div>
        <Comparison label="Con protección" value={safeRate(protectedSessions)} count={protectedSessions.length} color="#168F8A" />
        <Comparison label="Sin protección" value={safeRate(controlSessions)} count={controlSessions.length} color="#7A8C9E" />
        <div className="chart-insight"><ShieldCheck size={17} /> Repite cada escenario en ambas modalidades para obtener una comparación válida.</div>
      </section>
      <section className="chart-card">
        <div className="chart-title"><div><h3>Distribución de riesgo</h3><p>Máximo nivel alcanzado por sesión</p></div></div>
        <div className="bars">{riskCounts.map((count, index) => { const max = Math.max(...riskCounts, 1); return <div className="bar-item" key={index}><div className="bar-space"><div style={{ height: `${Math.max(5, count / max * 100)}%` }} /></div><strong>{count}</strong><span>{['Bajo', 'Medio', 'Alto', 'Crítico'][index]}</span></div> })}</div>
      </section>
    </div>
  </div>
}

function Metric({ icon, label, value }: { icon: React.ReactNode; label: string; value: string | number }) {
  return <div className="metric-card"><div>{icon}</div><span>{label}</span><strong>{value}</strong></div>
}

function Comparison({ label, value, count, color }: { label: string; value: number; count: number; color: string }) {
  return <div className="comparison"><div><strong>{label}</strong><span>{count} sesiones</span></div><div className="progress"><i style={{ width: `${value}%`, background: color }} /></div><b>{value}%</b></div>
}
