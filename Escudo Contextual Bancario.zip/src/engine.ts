import type { EventLog, EventType, RiskLevel } from './types'

export const eventConfig: Partial<Record<EventType, { points: number; label: string }>> = {
  CALL_STARTED: { points: 20, label: 'Llamada activa' },
  BANK_APP_OPENED: { points: 35, label: 'App financiera abierta durante llamada' },
  OTP_VIEW_REQUESTED: { points: 35, label: 'Clave dinámica consultada durante llamada' },
  NEW_BENEFICIARY: { points: 15, label: 'Beneficiario nuevo' },
  UNUSUAL_AMOUNT: { points: 15, label: 'Monto elevado' },
  SMS_RECEIVED: { points: 20, label: 'Mensaje con urgencia financiera' },
  SUSPICIOUS_LINK_OPENED: { points: 50, label: 'Enlace sospechoso abierto' },
}

export function scoreEvents(events: EventLog[]) {
  return Math.min(100, events.reduce((total, event) => total + event.score, 0))
}

export function riskLevel(score: number): RiskLevel {
  if (score >= 80) return 'Crítico'
  if (score >= 60) return 'Alto'
  if (score >= 30) return 'Medio'
  return 'Bajo'
}

export function riskColor(score: number) {
  if (score >= 80) return '#B42318'
  if (score >= 60) return '#B76534'
  if (score >= 30) return '#D18D28'
  return '#168F8A'
}

export function makeEvent(type: EventType, activeCall = false): EventLog {
  const base = eventConfig[type]
  let score = base?.points ?? 0
  if (type === 'BANK_APP_OPENED' && !activeCall) score = 0
  if (type === 'OTP_VIEW_REQUESTED' && !activeCall) score = 0
  return {
    id: crypto.randomUUID(),
    type,
    label: base?.label ?? eventLabels[type],
    timestamp: new Date().toISOString(),
    score,
  }
}

const eventLabels: Record<EventType, string> = {
  CALL_STARTED: 'Llamada iniciada',
  CALL_ENDED: 'Llamada finalizada',
  BANK_APP_OPENED: 'App financiera abierta',
  OTP_VIEW_REQUESTED: 'Clave dinámica consultada',
  TRANSFER_STARTED: 'Transferencia iniciada',
  NEW_BENEFICIARY: 'Beneficiario nuevo',
  UNUSUAL_AMOUNT: 'Monto elevado',
  SMS_RECEIVED: 'SMS recibido',
  SUSPICIOUS_LINK_OPENED: 'Enlace sospechoso abierto',
  BANK_APP_CLOSED: 'App financiera cerrada',
}
